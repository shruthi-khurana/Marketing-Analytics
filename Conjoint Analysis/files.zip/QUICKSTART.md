# Quick Start Guide

Get started with the TV Product Conjoint Analysis in 5 minutes.

## Prerequisites

- R version ≥ 4.0.0
- RStudio (recommended)
- Required packages: `readxl`

## Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/conjoint-analysis-project.git
   cd conjoint-analysis-project
   ```

2. **Install dependencies**:
   ```r
   install.packages("readxl")
   ```

3. **Add your data**:
   - Place your `Design_Matrix.xlsx` file in the `data/` directory
   - Or use the example data structure (see `data/README.md`)

## Running the Analysis

### Option 1: R Script (Command Line)

```r
# Load function
source("conjoint_analysis.R")

# Run analysis
results <- conjoint_analysis(
  preferences_file = "data/Design_Matrix.xlsx",
  own_design = c(
    "Resolution 4K = 1" = 1,
    "Sony = 1" = 1,
    "Price (low = 0; hi =1)" = 0,
    "Screen 75 inch" = 1,
    "Screen 85 inch" = 0
  ),
  compA_design = c(
    "Resolution 4K = 1" = 1,
    "Sony = 1" = 1,
    "Price (low = 0; hi =1)" = 1,
    "Screen 75 inch" = 1,
    "Screen 85 inch" = 0
  ),
  compB_design = c(
    "Resolution 4K = 1" = 1,
    "Sony = 1" = 0,
    "Price (low = 0; hi =1)" = 0,
    "Screen 75 inch" = 1,
    "Screen 85 inch" = 0
  ),
  feature_costs = c(1000, 500, 1000, 250, 250)
)

# View results
print(results$Partworth_Table)
print(results$Attribute_Importance)
cat(sprintf("Optimal Price: $%d\n", results$Optimal_Price))
cat(sprintf("Max Profit: $%.2f\n", results$Maximum_Profit))
```

### Option 2: R Markdown (Full Report)

1. Open `analysis.Rmd` in RStudio
2. Click "Knit" → "Knit to PDF" or "Knit to HTML"
3. View the generated report in `outputs/`

## Understanding the Outputs

### Part-Worth Table
Shows utility value for each feature:
- **Positive values**: Feature increases preference
- **Negative values**: Feature decreases preference
- **Magnitude**: Larger absolute value = stronger effect

### Attribute Importance
Percentages showing relative influence:
- Sum to 100%
- Higher % = more important in decision-making

### Willingness to Pay
Dollar amount consumers would pay for each feature:
- Calculated from part-worths and price coefficient
- Direct measure of feature value

### Market Share
Predicted market share vs. competitors:
- Uses multinomial logit model
- Higher utility = higher share

### Optimal Price & Profit
Price that maximizes profit:
- Balances margin and volume
- Accounts for competitive dynamics

## Customizing the Analysis

### Change Product Configuration

Edit the `own_design` vector:

```r
own_design = c(
  "Resolution 4K = 1" = 1,      # 1 = 4K, 0 = Standard
  "Sony = 1" = 0,                # 1 = Sony, 0 = Other brand
  "Price (low = 0; hi =1)" = 0,  # 0 = Low, 1 = High
  "Screen 75 inch" = 0,          # 1 = 75", 0 = otherwise
  "Screen 85 inch" = 1           # 1 = 85", 0 = otherwise
)
```

### Change Feature Costs

Update the `feature_costs` vector:

```r
# Order: [4K, Sony, HighPrice, 75", 85"]
feature_costs = c(1200, 600, 1000, 300, 400)  # New costs
```

### Test Different Price Points

Modify the price range in `conjoint_analysis.R`:

```r
prices <- seq(1500, 3000, by = 50)  # Test $1,500-$3,000 in $50 increments
```

## Exporting Results

### Save to CSV

```r
# Export tables
write.csv(results$Partworth_Table, "outputs/partworth_table.csv")
write.csv(results$Attribute_Importance, "outputs/attribute_importance.csv")
write.csv(results$Market_Share, "outputs/market_share.csv")
write.csv(results$Willingness_to_Pay, "outputs/wtp_table.csv")
```

### Save Plots

The plots are automatically displayed. To save them:

```r
# Re-run analysis with plot saving
png("outputs/market_share_plot.png", width=800, height=600)
# ... run analysis to generate plot ...
dev.off()
```

## Troubleshooting

### Error: "cannot open file 'Design_Matrix.xlsx'"
- Check that the file is in the `data/` directory
- Verify the filename matches exactly (case-sensitive)
- Ensure the file isn't open in Excel

### Error: "package 'readxl' not found"
```r
install.packages("readxl")
```

### Plots not showing
- Run in RStudio for best results
- Check graphics device: `dev.list()`
- Reset device: `dev.off()`

### Results seem incorrect
- Verify data quality in Excel file
- Check for missing values
- Ensure preference ratings are numeric (1-10)
- Confirm feature columns are binary (0 or 1)

## Next Steps

1. **Customize for your data**: Modify feature names and levels
2. **Explore sensitivity**: Test different scenarios
3. **Segment analysis**: Run separately for customer groups
4. **Share findings**: Use generated reports and visualizations

## Getting Help

- **Documentation**: See `docs/methodology.md` for detailed explanations
- **Examples**: Check `docs/findings.md` for interpretation guide
- **Issues**: Open an issue on GitHub
- **Contributing**: See `CONTRIBUTING.md`

## Example Workflow

```r
# 1. Load function
source("conjoint_analysis.R")

# 2. Run analysis (your configuration)
results <- conjoint_analysis(
  preferences_file = "data/Design_Matrix.xlsx",
  own_design = c(...),
  compA_design = c(...),
  compB_design = c(...),
  feature_costs = c(...)
)

# 3. Review key metrics
cat("Optimal Price:", results$Optimal_Price, "\n")
cat("Max Profit:", results$Maximum_Profit, "\n")
print(results$Market_Share)

# 4. Export results
write.csv(results$Partworth_Table, "outputs/partworth_table.csv")

# 5. Generate full report (optional)
rmarkdown::render("analysis.Rmd")
```

That's it! You're ready to run conjoint analysis. 🚀

---

**Questions?** Check the full documentation or open an issue on GitHub.
